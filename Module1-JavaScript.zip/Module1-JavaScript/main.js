// =====================================================
// 1. JavaScript Basics & Setup
// =====================================================

console.log("Welcome to the Community Portal");

window.onload = function () {
    alert("Page Fully Loaded");
};

// =====================================================
// 2. Syntax, Data Types, Operators
// =====================================================

const eventName = "Music Fiesta";
const eventDate = "2026-08-10";

let seats = 5;

console.log(
    `Event: ${eventName}, Date: ${eventDate}, Seats: ${seats}`
);

// =====================================================
// 5. Objects and Prototypes
// =====================================================

class EventPortal {

    constructor(name, category, date, seats, location) {

        this.name = name;
        this.category = category;
        this.date = date;
        this.seats = seats;
        this.location = location;
    }
}

EventPortal.prototype.checkAvailability = function () {

    return this.seats > 0
        ? "Seats Available"
        : "Full";
};

// =====================================================
// 6. Arrays and Methods
// =====================================================

let events = [

    new EventPortal(
        "Music Fiesta",
        "Music",
        "2026-08-10",
        5,
        "Hyderabad"
    ),

    new EventPortal(
        "Football Match",
        "Sports",
        "2026-09-20",
        10,
        "Guntur"
    ),

    new EventPortal(
        "Dance Night",
        "Music",
        "2026-12-01",
        8,
        "Chennai"
    ),

    new EventPortal(
        "Coding Workshop",
        "Workshop",
        "2026-11-11",
        6,
        "Vijayawada"
    ),

    new EventPortal(
        "Old Event",
        "Music",
        "2024-01-01",
        0,
        "Delhi"
    )
];

// push()
events.push(
    new EventPortal(
        "Art Festival",
        "Workshop",
        "2026-10-05",
        7,
        "Mumbai"
    )
);

// filter()
const musicEvents =
    events.filter(event =>
        event.category === "Music"
    );

console.log(musicEvents);

// map()
const formattedEvents =
    events.map(event =>
        `Workshop on ${event.name}`
    );

console.log(formattedEvents);

// Object.entries()
events.forEach(event => {

    console.log(Object.entries(event));
});

// =====================================================
// 4. Functions, Scope, Closures
// =====================================================

function addEvent(event) {

    events.push(event);

    renderEvents(events);
}

function registerUser(eventName) {

    try {

        let foundEvent =
            events.find(e => e.name === eventName);

        if (!foundEvent) {

            throw new Error("Event Not Found");
        }

        if (foundEvent.seats <= 0) {

            throw new Error("No Seats Available");
        }

        foundEvent.seats--;

        renderEvents(events);

        console.log(`Registered for ${eventName}`);

    } catch (error) {

        console.error(error.message);

        alert(error.message);
    }
}

function filterEventsByCategory(category, callback) {

    let filtered = events.filter(event =>
        category === "All"
            ? true
            : event.category === category
    );

    callback(filtered);
}

// Closure
function registrationTracker() {

    let totalRegistrations = 0;

    return function () {

        totalRegistrations++;

        document.getElementById("counter")
            .innerText =
            `Total Registrations: ${totalRegistrations}`;
    };
}

const trackRegistration =
    registrationTracker();

// =====================================================
// 7. DOM Manipulation
// =====================================================

const eventsContainer =
    document.querySelector("#eventsContainer");

function renderEvents(eventList) {

    eventsContainer.innerHTML = "";

    eventList.forEach(event => {

        let today =
            new Date().toISOString().split("T")[0];

        // if else
        if (event.date < today || event.seats <= 0) {

            return;
        }

        let card =
            document.createElement("div");

        card.classList.add("event-card");

        // destructuring
        const {
            name,
            category,
            date,
            seats,
            location
        } = event;

        card.innerHTML = `

            <h3>${name}</h3>

            <p><b>Category:</b> ${category}</p>

            <p><b>Date:</b> ${date}</p>

            <p><b>Location:</b> ${location}</p>

            <p><b>Seats:</b> ${seats}</p>

            <p><b>Status:</b>
            ${event.checkAvailability()}</p>

            <button onclick="handleRegister('${name}')">
                Register
            </button>

            <button onclick="cancelRegistration('${name}')">
                Cancel
            </button>
        `;

        eventsContainer.appendChild(card);
    });

    $(".event-card").fadeIn();
}

renderEvents(events);

// =====================================================
// 8. Event Handling
// =====================================================

function handleRegister(name) {

    registerUser(name);

    trackRegistration();

    $(".event-card")
        .fadeOut(200)
        .fadeIn(200);
}

function cancelRegistration(name) {

    let foundEvent =
        events.find(e => e.name === name);

    if (foundEvent) {

        foundEvent.seats++;

        renderEvents(events);
    }
}

// onchange
document.getElementById("categoryFilter")
    .onchange = function () {

        filterEventsByCategory(
            this.value,
            renderEvents
        );
    };

// keyup search
document.getElementById("searchBox")
    .addEventListener("keyup", function () {

        let text =
            this.value.toLowerCase();

        let searched =
            events.filter(event =>
                event.name
                    .toLowerCase()
                    .includes(text)
            );

        renderEvents(searched);
    });

// onclick
document.getElementById("showMusicBtn")
    .onclick = function () {

        renderEvents(musicEvents);
    };

// =====================================================
// 9. Async JS
// =====================================================

document.getElementById("loading")
    .style.display = "block";

fetch("https://jsonplaceholder.typicode.com/users")

    .then(response => response.json())

    .then(data => {

        console.log(data);

        document.getElementById("loading")
            .style.display = "none";
    })

    .catch(error => {

        console.error(error);

        document.getElementById("loading")
            .style.display = "none";
    });

async function fetchEventsAsync() {

    try {

        document.getElementById("loading")
            .style.display = "block";

        const response =
            await fetch(
                "https://jsonplaceholder.typicode.com/posts"
            );

        const data =
            await response.json();

        console.log(data);

        document.getElementById("loading")
            .style.display = "none";

    } catch (error) {

        console.error(error);

        document.getElementById("loading")
            .style.display = "none";
    }
}

fetchEventsAsync();

// =====================================================
// 10. Modern JavaScript
// =====================================================

function greetUser(name = "Guest") {

    console.log(`Welcome ${name}`);
}

greetUser();

let clonedEvents = [...events];

console.log(clonedEvents);

// =====================================================
// 11. Working with Forms
// =====================================================

const form =
    document.getElementById("registrationForm");

form.addEventListener("submit", function (event) {

    event.preventDefault();

    console.log("Form Submitted");

    let username =
        form.elements["username"].value;

    let email =
        form.elements["email"].value;

    let selectedEvent =
        form.elements["selectedEvent"].value;

    document.getElementById("nameError")
        .innerText = "";

    document.getElementById("emailError")
        .innerText = "";

    document.getElementById("eventError")
        .innerText = "";

    let valid = true;

    if (username === "") {

        document.getElementById("nameError")
            .innerText = "Name Required";

        valid = false;
    }

    if (email === "") {

        document.getElementById("emailError")
            .innerText = "Email Required";

        valid = false;
    }

    if (selectedEvent === "") {

        document.getElementById("eventError")
            .innerText = "Please Select Event";

        valid = false;
    }

    if (!valid) {

        return;
    }

    // =====================================================
    // 12. AJAX & Fetch API
    // =====================================================

    let userData = {

        username,
        email,
        selectedEvent
    };

    console.log(userData);

    setTimeout(() => {

        fetch(
            "https://jsonplaceholder.typicode.com/posts",

            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify(userData)
            }
        )

            .then(response => response.json())

            .then(data => {

                console.log(data);

                document.getElementById("message")
                    .innerHTML =
                    "<span style='color:green'>Registration Successful</span>";
            })

            .catch(error => {

                console.error(error);

                document.getElementById("message")
                    .innerHTML =
                    "<span style='color:red'>Registration Failed</span>";
            });

    }, 2000);
});

// =====================================================
// 13. Debugging and Testing
// =====================================================

console.log("Debugging Started");

function debugTest() {

    let testVariable = "Testing";

    console.log(testVariable);

    debugger;
}

debugTest();

// =====================================================
// 14. jQuery and JS Frameworks
// =====================================================

$("#registerBtn").click(function () {

    console.log("jQuery Button Clicked");
});

$(".event-card").fadeIn();

console.log(
    "React and Vue provide reusable components and faster UI updates."
);