import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorServiceCallableExample {

    public static void main(String[] args) {

        // Create a thread pool with 3 threads
        ExecutorService executor = Executors.newFixedThreadPool(3);

        try {

            // Define Callable tasks
            Callable<Integer> task1 = () -> {
                return 10 + 20;
            };

            Callable<Integer> task2 = () -> {
                return 30 + 40;
            };

            Callable<Integer> task3 = () -> {
                return 50 + 60;
            };

            // Submit tasks and get Future objects
            Future<Integer> future1 = executor.submit(task1);
            Future<Integer> future2 = executor.submit(task2);
            Future<Integer> future3 = executor.submit(task3);

            // Retrieve results using Future.get()
            System.out.println("Result of Task 1: " + future1.get());
            System.out.println("Result of Task 2: " + future2.get());
            System.out.println("Result of Task 3: " + future3.get());

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            // Shut down the executor
            executor.shutdown();
        }
    }
}