// Interface
interface Playable {

    // Abstract method
    void play();
}

// Guitar class implementing Playable
class Guitar implements Playable {

    @Override
    public void play() {
        System.out.println("Playing the Guitar");
    }
}

// Piano class implementing Playable
class Piano implements Playable {

    @Override
    public void play() {
        System.out.println("Playing the Piano");
    }
}

public class InterfaceImplementation {

    public static void main(String[] args) {

        // Create objects
        Guitar guitar = new Guitar();
        Piano piano = new Piano();

        // Call play() methods
        System.out.println("Guitar:");
        guitar.play();

        System.out.println("Piano:");
        piano.play();
    }
}