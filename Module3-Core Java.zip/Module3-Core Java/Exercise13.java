import java.util.Scanner;

public class RecursiveFibonacci {

    // Recursive method to find Fibonacci number
    static int fibonacci(int n) {

        if (n == 0) {
            return 0;
        }

        if (n == 1) {
            return 1;
        }

        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter a positive integer: ");
        int n = sc.nextInt();

        // Display Fibonacci result
        if (n < 0) {
            System.out.println("Please enter a positive integer.");
        } else {
            System.out.println("Fibonacci number at position " + n + " is " + fibonacci(n));
        }

        sc.close();
    }
}