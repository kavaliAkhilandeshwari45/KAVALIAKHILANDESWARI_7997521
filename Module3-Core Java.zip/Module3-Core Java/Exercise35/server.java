import java.io.*;
import java.net.*;

public class Server {

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(5000);
            System.out.println("Server started. Waiting for client...");

            Socket socket = serverSocket.accept();
            System.out.println("Client connected.");

            BufferedReader serverInput =
                    new BufferedReader(new InputStreamReader(System.in));

            BufferedReader clientInput =
                    new BufferedReader(new InputStreamReader(socket.getInputStream()));

            PrintWriter out =
                    new PrintWriter(socket.getOutputStream(), true);

            String message;

            while (true) {
                // Receive from client
                message = clientInput.readLine();
                System.out.println("Client: " + message);

                if (message.equalsIgnoreCase("exit")) {
                    break;
                }

                // Send to client
                System.out.print("Server: ");
                String reply = serverInput.readLine();
                out.println(reply);

                if (reply.equalsIgnoreCase("exit")) {
                    break;
                }
            }

            socket.close();
            serverSocket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}