import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LambdaExpressionExample {

    public static void main(String[] args) {

        // Create a List of strings
        List<String> names = new ArrayList<>();

        names.add("Charlie");
        names.add("Alice");
        names.add("David");
        names.add("Bob");

        // Sort the list using a lambda expression
        Collections.sort(names, (name1, name2) -> name1.compareTo(name2));

        // Display the sorted list
        System.out.println("Sorted List:");

        for (String name : names) {
            System.out.println(name);
        }
    }
}