public class Employee {

    private int id;
    private String name;
    private double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public void displayDetails() {
        System.out.println("Employee ID: " + id);
        System.out.println("Employee Name: " + name);
        System.out.println("Employee Salary: " + salary);
    }

    public double calculateAnnualSalary() {
        return salary * 12;
    }

    public static void main(String[] args) {

        Employee emp = new Employee(
                101,
                "Akhila",
                50000.0
        );

        emp.displayDetails();

        System.out.println(
                "Annual Salary: " +
                emp.calculateAnnualSalary()
        );
    }
}