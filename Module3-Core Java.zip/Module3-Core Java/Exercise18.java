// Base class
class Animal {

    // Method in Animal class
    void makeSound() {
        System.out.println("Animal makes a sound");
    }
}

// Subclass Dog inheriting from Animal
class Dog extends Animal {

    // Overriding makeSound() method
    @Override
    void makeSound() {
        System.out.println("Bark");
    }
}

public class InheritanceExample {

    public static void main(String[] args) {

        // Create Animal object
        Animal animal = new Animal();

        // Create Dog object
        Dog dog = new Dog();

        // Call methods
        System.out.println("Animal Sound:");
        animal.makeSound();

        System.out.println("Dog Sound:");
        dog.makeSound();
    }
}