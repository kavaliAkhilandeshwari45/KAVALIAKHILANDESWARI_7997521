import java.sql.*;

class StudentDAO {

    private static final String URL = "jdbc:sqlite:students.db";

    // Insert Student Record
    public void insertStudent(int id, String name, int age) {
        String sql = "INSERT INTO students(id, name, age) VALUES (?, ?, ?)";

        try (Connection con = DriverManager.getConnection(URL);
             PreparedStatement pstmt = con.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setInt(3, age);

            int rows = pstmt.executeUpdate();
            System.out.println(rows + " record inserted.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update Student Record
    public void updateStudent(int id, String newName, int newAge) {
        String sql = "UPDATE students SET name = ?, age = ? WHERE id = ?";

        try (Connection con = DriverManager.getConnection(URL);
             PreparedStatement pstmt = con.prepareStatement(sql)) {

            pstmt.setString(1, newName);
            pstmt.setInt(2, newAge);
            pstmt.setInt(3, id);

            int rows = pstmt.executeUpdate();
            System.out.println(rows + " record updated.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        StudentDAO dao = new StudentDAO();

        // Insert a new student
        dao.insertStudent(3, "Akhila", 21);

        // Update student details
        dao.updateStudent(3, "Akhila Reddy", 22);
    }
}