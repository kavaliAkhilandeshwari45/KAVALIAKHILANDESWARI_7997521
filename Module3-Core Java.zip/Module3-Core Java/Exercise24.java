import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListExample {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Create ArrayList to store student names
        ArrayList<String> studentNames = new ArrayList<>();

        // Get number of students
        System.out.print("How many student names do you want to enter? ");
        int n = sc.nextInt();
        sc.nextLine(); // Consume newline

        // Add names to the ArrayList
        for (int i = 1; i <= n; i++) {
            System.out.print("Enter name " + i + ": ");
            String name = sc.nextLine();
            studentNames.add(name);
        }

        // Display all names
        System.out.println("\nStudent Names:");
        for (String name : studentNames) {
            System.out.println(name);
        }

        sc.close();
    }
}