import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileWritingExample {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter a string: ");
        String text = sc.nextLine();

        try {
            // Write to output.txt
            FileWriter writer = new FileWriter("output.txt");
            writer.write(text);
            writer.close();

            System.out.println("Data has been successfully written to output.txt");
        }
        catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        sc.close();
    }
}