import java.sql.*;

public class TransactionDemo {

    private static final String URL = "jdbc:sqlite:bank.db";

    // Money Transfer Method
    public static void transfer(int fromAccount, int toAccount, double amount) {

        Connection con = null;

        try {
            con = DriverManager.getConnection(URL);

            // Start Transaction
            con.setAutoCommit(false);

            // Debit Amount
            PreparedStatement debit = con.prepareStatement(
                    "UPDATE accounts SET balance = balance - ? WHERE account_id = ?");
            debit.setDouble(1, amount);
            debit.setInt(2, fromAccount);
            debit.executeUpdate();

            // Credit Amount
            PreparedStatement credit = con.prepareStatement(
                    "UPDATE accounts SET balance = balance + ? WHERE account_id = ?");
            credit.setDouble(1, amount);
            credit.setInt(2, toAccount);
            credit.executeUpdate();

            // Commit Transaction
            con.commit();
            System.out.println("Transaction Successful!");

        } catch (Exception e) {
            try {
                if (con != null) {
                    con.rollback();
                    System.out.println("Transaction Failed! Rolled Back.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();

        } finally {
            try {
                if (con != null) {
                    con.setAutoCommit(true);
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        transfer(1, 2, 500);
    }
}