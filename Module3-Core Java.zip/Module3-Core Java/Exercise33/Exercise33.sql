CREATE TABLE accounts (
    account_id INTEGER PRIMARY KEY,
    balance REAL
);

INSERT INTO accounts VALUES (1, 5000);
INSERT INTO accounts VALUES (2, 3000);