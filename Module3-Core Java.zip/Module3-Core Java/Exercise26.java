// Class implementing Runnable
class MessagePrinter implements Runnable {

    private String message;

    public MessagePrinter(String message) {
        this.message = message;
    }

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(message + " - Count: " + i);
        }
    }
}

public class ThreadCreationExample {

    public static void main(String[] args) {

        // Create Runnable objects
        MessagePrinter task1 = new MessagePrinter("Thread 1 is running");
        MessagePrinter task2 = new MessagePrinter("Thread 2 is running");

        // Create Thread objects
        Thread thread1 = new Thread(task1);
        Thread thread2 = new Thread(task2);

        // Start threads
        thread1.start();
        thread2.start();
    }
}