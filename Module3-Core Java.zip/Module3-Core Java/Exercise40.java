import java.util.ArrayList;
import java.util.List;

public class VirtualThreadsExample {

    public static void main(String[] args) throws InterruptedException {

        int numberOfThreads = 100_000;

        long startTime = System.currentTimeMillis();

        List<Thread> threads = new ArrayList<>();

        for (int i = 0; i < numberOfThreads; i++) {

            int taskId = i;

            Thread vt = Thread.startVirtualThread(() -> {
                System.out.println("Virtual Thread Task: " + taskId);
            });

            threads.add(vt);
        }

        // Wait for all virtual threads to finish
        for (Thread thread : threads) {
            thread.join();
        }

        long endTime = System.currentTimeMillis();

        System.out.println("\nTotal Virtual Threads: " + numberOfThreads);
        System.out.println("Execution Time: " +
                (endTime - startTime) + " ms");
    }
}