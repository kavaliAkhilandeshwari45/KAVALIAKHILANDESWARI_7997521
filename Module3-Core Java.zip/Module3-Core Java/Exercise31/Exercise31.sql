CREATE TABLE students (
    id INTEGER PRIMARY KEY,
    name TEXT,
    age INTEGER
);

INSERT INTO students VALUES (1, 'Akhila', 21);
INSERT INTO students VALUES (2, 'Ravi', 22);