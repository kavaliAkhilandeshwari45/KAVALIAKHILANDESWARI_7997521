import java.sql.*;

public class Exercise31 {
    public static void main(String[] args) {
        try {
            // Load JDBC Driver
            Class.forName("org.sqlite.JDBC");

            // Create Connection
            Connection con = DriverManager.getConnection("jdbc:sqlite:students.db");

            // Create Statement
            Statement stmt = con.createStatement();

            // Execute SELECT Query
            ResultSet rs = stmt.executeQuery("SELECT * FROM students");

            // Print Results
            System.out.println("Student Records:");
            while (rs.next()) {
                System.out.println(
                    rs.getInt("id") + " | " +
                    rs.getString("name") + " | " +
                    rs.getInt("age")
                );
            }

            // Close Resources
            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}