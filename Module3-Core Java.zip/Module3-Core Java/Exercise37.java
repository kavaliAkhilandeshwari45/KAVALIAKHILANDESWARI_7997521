public class Demo {

    private int number;

    // Constructor
    public Demo(int number) {
        this.number = number;
    }

    // Method to add two numbers
    public int add(int a, int b) {
        int sum = a + b;
        return sum;
    }

    // Method to display information
    public void display() {
        System.out.println("Number = " + number);
    }

    public static void main(String[] args) {

        Demo obj = new Demo(10);

        int result = obj.add(20, 30);

        System.out.println("Addition Result = " + result);

        obj.display();
    }
}