import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

// Record definition (Java 16+)
record Person(String name, int age) {}

public class RecordsExample {

    public static void main(String[] args) {

        // Create record instances
        Person person1 = new Person("Alice", 25);
        Person person2 = new Person("Bob", 17);
        Person person3 = new Person("Charlie", 30);

        // Print record instances
        System.out.println("Person Records:");
        System.out.println(person1);
        System.out.println(person2);
        System.out.println(person3);

        // Store records in a List
        List<Person> people = Arrays.asList(
                person1,
                person2,
                person3
        );

        // Filter people whose age is 18 or above
        List<Person> adults = people.stream()
                .filter(person -> person.age() >= 18)
                .collect(Collectors.toList());

        // Display filtered records
        System.out.println("\nAdults (Age >= 18):");
        adults.forEach(System.out::println);
    }
}