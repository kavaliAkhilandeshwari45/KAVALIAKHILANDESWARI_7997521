public class OperatorPrecedence {

    public static void main(String[] args) {

        // Expression 1
        int result1 = 10 + 5 * 2;

        // Expression 2
        int result2 = (10 + 5) * 2;

        // Expression 3
        int result3 = 20 / 5 + 3 * 4 - 2;

        // Display results
        System.out.println("Result of 10 + 5 * 2 = " + result1);
        System.out.println("Result of (10 + 5) * 2 = " + result2);
        System.out.println("Result of 20 / 5 + 3 * 4 - 2 = " + result3);

        // Explanation
        System.out.println("\nOrder of Operations:");
        System.out.println("1. Parentheses ()");
        System.out.println("2. Multiplication (*) and Division (/)");
        System.out.println("3. Addition (+) and Subtraction (-)");
    }
}