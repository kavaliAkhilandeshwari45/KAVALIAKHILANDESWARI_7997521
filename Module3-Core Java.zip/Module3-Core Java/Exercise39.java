import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

// Class to be loaded dynamically
class Student {

    public void displayInfo() {
        System.out.println("Student Information Displayed");
    }

    public void greet(String name) {
        System.out.println("Hello, " + name);
    }
}

public class ReflectionExample {

    public static void main(String[] args) {

        try {

            // Load class dynamically
            Class<?> clazz = Class.forName("Student");

            System.out.println("Class Name: " + clazz.getName());

            // Print all declared methods and parameters
            System.out.println("\nMethods:");

            Method[] methods = clazz.getDeclaredMethods();

            for (Method method : methods) {

                System.out.print("Method: " + method.getName());

                Parameter[] parameters = method.getParameters();

                if (parameters.length > 0) {
                    System.out.print(" | Parameters: ");

                    for (Parameter parameter : parameters) {
                        System.out.print(
                            parameter.getType().getSimpleName() + " "
                        );
                    }
                }

                System.out.println();
            }

            // Create object dynamically
            Object obj = clazz.getDeclaredConstructor().newInstance();

            // Invoke displayInfo()
            Method displayMethod =
                    clazz.getMethod("displayInfo");

            displayMethod.invoke(obj);

            // Invoke greet(String)
            Method greetMethod =
                    clazz.getMethod("greet", String.class);

            greetMethod.invoke(obj, "Alice");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}