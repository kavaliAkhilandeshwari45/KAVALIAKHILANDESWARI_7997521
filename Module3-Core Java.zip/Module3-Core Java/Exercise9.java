import java.util.Scanner;

public class GradeCalculator {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Prompt user for marks
        System.out.print("Enter marks out of 100: ");
        int marks = sc.nextInt();

        // Determine grade using if-else statements
        if (marks >= 90 && marks <= 100) {
            System.out.println("Grade: A");
        } 
        else if (marks >= 80) {
            System.out.println("Grade: B");
        } 
        else if (marks >= 70) {
            System.out.println("Grade: C");
        } 
        else if (marks >= 60) {
            System.out.println("Grade: D");
        } 
        else if (marks >= 0) {
            System.out.println("Grade: F");
        } 
        else {
            System.out.println("Invalid marks entered.");
        }

        sc.close();
    }
}